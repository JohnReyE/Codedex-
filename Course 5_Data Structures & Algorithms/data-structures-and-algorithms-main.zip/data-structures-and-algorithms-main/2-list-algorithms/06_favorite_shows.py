# Favorite Shows 📺
# Codédex

favorite_shows = ['The Last of Us', 'Band of Brothers', 'Game of Thrones']

print(favorite_shows[0])
print(favorite_shows[1])
print(favorite_shows[2])

favorite_shows.append('Severance')

print(len(favorite_shows))

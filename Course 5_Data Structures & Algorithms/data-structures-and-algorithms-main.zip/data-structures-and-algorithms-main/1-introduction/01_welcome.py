# Welcome 👋
# Codédex

concepts = ['queues', 'graphs', 'stacks', 'recursion', 'dijkstra\'s algorithm']

concepts.sort()
print(concepts)
# Amazon Delivery 🚚
# Codédex

print('I would use a dictionary to keep track of package addresses, with the package ID as the key and the address as the value.')

packages = {
  1: "123 Main St",
  2: "456 Elm St",
  3: "789 Oak St",
  4: "101 Pine St",
  5: "202 Maple St"
}

print('Starting from Jersey, I would go into the city, go down to drop off the two packages in Brooklyn, and drive up to get the one east.')

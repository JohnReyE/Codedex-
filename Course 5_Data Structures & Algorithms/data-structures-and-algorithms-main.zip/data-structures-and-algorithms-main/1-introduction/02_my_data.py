# My Data 🙂
# Codédex

friends = ['helly', 'irving', 'dylan']

song = {
  'name': 'Swimming',
  'artist': 'Flawed Mangoes',
  'year': 2024
}

places = {'Japan', 'Hawaii', 'Yosemite', 'Morocco', 'Taiwan'}
          
print(friends)
print(song)
print(places)

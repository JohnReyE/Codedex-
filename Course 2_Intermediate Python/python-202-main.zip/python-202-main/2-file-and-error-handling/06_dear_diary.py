# Dear Diary 📔
# Codédex

with open('diaries.txt', 'w') as file:
  file.write('Date: March 19, 2024 \n')
  file.write('Dear Diary...')

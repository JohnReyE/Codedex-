# Full Circle ⭕️
# Codédex

def circle_area(radius):
  # Pure function to calculate the area of a circle.
  return 3.14 * radius ** 2

# Test the pure function
radius_of_circle = 5
area_of_circle = circle_area(radius_of_circle)

# Print to prove result
print('Area of the circle:', area_of_circle)

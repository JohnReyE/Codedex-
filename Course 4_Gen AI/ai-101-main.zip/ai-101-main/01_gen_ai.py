# Gen AI 🤖
# Codédex

print("I love to use Google Gemini for poetry")

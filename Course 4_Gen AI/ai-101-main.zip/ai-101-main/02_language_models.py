# Language Models 👅
# Codédex

# Activate the virtual environment
pip install virtualenv
virtualenv nlp_env
    
# Install necessary libraries
pip install nltk numpy

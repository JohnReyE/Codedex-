# Grades 💯
# Codédex

grade = 58

if grade >= 55:
  print('You passed.')
else:
  print('You failed.')

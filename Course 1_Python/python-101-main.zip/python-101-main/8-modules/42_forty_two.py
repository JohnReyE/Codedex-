# Forty Two 4️⃣2️⃣
# Codédex

import wikipedia

print(wikipedia.search('Philosophy of life'))
# Snail Mail 💌
# Codédex

print('+---------------------------------------------------------------------+')
print('|                                                          June 2022  |')
print('|                                                       Brooklyn, NY  |')
print('|  Dear Self,                                                         |')
print('|                                                                     |')
print('|      Build the learn to code platform that you always dreamed of.   |')
print('|      Give more than you take.                                       |')
print('|      Care > capital.                                                |')
print('|      Five-second funerals for all the Ls.                           |')
print('|      And always get back up.                                        |')
print('|                                                                     |')
print('|                                              Sonny Li 🤠            |')
print('|                                                                     |')
print('+---------------------------------------------------------------------+')

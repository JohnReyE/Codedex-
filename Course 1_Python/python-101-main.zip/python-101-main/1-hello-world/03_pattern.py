print('       1')
print('     2 3')
print('   4 5 6')
print('7 8 9 10')

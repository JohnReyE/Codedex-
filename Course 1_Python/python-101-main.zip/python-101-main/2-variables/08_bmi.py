# BMI 🏋️‍♀️
# Codédex

weight = 92.3
height = 1.86

bmi = weight / (height**2)

print(bmi)
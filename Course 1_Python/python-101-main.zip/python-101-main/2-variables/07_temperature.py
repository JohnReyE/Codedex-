# Temperature 🌡
# Codédex

temp_f = 56
temp_c = (temp_f - 32) / 1.8

print(temp_c)
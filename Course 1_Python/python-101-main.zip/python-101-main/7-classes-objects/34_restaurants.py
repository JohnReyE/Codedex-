# Restaurants 🍽️ 
# Codédex

class Restaurant:
  name = ''
  category = ''
  rating = 0.0
  delivery = True

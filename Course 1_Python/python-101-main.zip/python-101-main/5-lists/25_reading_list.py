# Reading List 📚
# Codédex

books = ['Harry Potter',
         '1984',
         'The Fault in Our Stars',
         'The Mom Test',
         'Life in Code']

print(books)

books.append('Pachinko')
books.remove('The Fault in Our Stars')
books.pop(1)

print(books)

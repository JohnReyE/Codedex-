# Mixtape: Classical Relaxation Theme 💿
# Codédex

playlist = ['Johannes Brahms - Symphony No.1 in C Minor, Op. 68', 
            'Erik Satie - Gymnopédie No.1', 
            'Tchaikovsky - 1812 Overture',
            'Edvard Grieg - In the Hall of the Mountain King',
            'Ludwig van Beethoven - Moonlight Sonata', 
            'Antonio Vivaldi - The Four Seasons']

for song in playlist:
  print(song)

# Mars Orbiter 🚀
# Codédex

def distance_to_miles(distance):
  return distance / 1.609

answer = distance_to_miles(10000)
print(answer)

# Calculator 🔢
# Codédex

def add(a, b):
  return a + b

def subtract(a, b):
  return a - b

def multiply(a, b):
  return a * b

def divide(a, b):
  return a / b

def exp(a, b):
  return a ** b

print(add(3, 5))
print(subtract(7, 2))
print(multiply(4, 8))
print(divide(9, 3))
print(exp(2, 3))
